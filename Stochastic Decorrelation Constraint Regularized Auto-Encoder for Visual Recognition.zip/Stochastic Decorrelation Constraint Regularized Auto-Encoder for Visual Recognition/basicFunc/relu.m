
function y = relu(x)

    y = max(x,0);

end