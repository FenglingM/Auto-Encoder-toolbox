





% test gpu conv
% input configuration
%-----------------------------------------------------------------------
% img = randn(225,225,3,9000,'single');
% filter = randn(10,10,3,1000,'single');
% bias = randn(1000,1,'single');
% pool_size = 54;


function AE = gpu_conv_feature(img, AE )
img = single(img);
[AE{1}.conv_dim, ~, ~, num_images] = size(img);
AE{1}.pool_dim = AE{1}.conv_dim;
for i=2:numel(AE)
    AE{i}.conv_dim = ( AE{i-1}.pool_dim - AE{i}.kernelsize + 1 ) ;
    AE{i}.pool_dim = AE{i}.conv_dim / AE{i}.poolsize;
%     AE{i}.outputsize = size(AE{i}.W, 2);
    AE{i}.kcol =  parallel.gpu.CUDAKernel('im2col.ptx','im2col.cu'); 
    AE{i}.conv_nth = AE{i}.outputsize * AE{i}.conv_dim^2;
    AE{i}.kcol.ThreadBlockSize = [1024];
    AE{i}.kcol.GridSize = [floor((AE{i}.conv_nth + 1024 - 1) / 1024)];
    AE{i}.pool_dim = floor(AE{i}.conv_dim / AE{i}.poolsize);
    AE{i}.pool_nth = AE{i}.outputsize * AE{i}.pool_dim^2;
    AE{i}.kmax = parallel.gpu.CUDAKernel('MaxPool.ptx','MaxPool.cu'); 
    AE{i}.kmax.ThreadBlockSize = [1024];
    AE{i}.kmax.GridSize = [floor((AE{i}.pool_nth + 1024 - 1) / 1024)];
    AE{i}.kmean = parallel.gpu.CUDAKernel('meanpool.ptx','meanpool.cu'); 
    AE{i}.kmean.ThreadBlockSize = [1024];
    AE{i}.kmean.GridSize = [floor((AE{i}.pool_nth + 1024 - 1) / 1024)];
%     AE{i}.a = gpuArray.zeros(AE{i}.pool_dim, AE{i}.pool_dim, AE{i}.outputsize, 'single');
    AE{i}.spma = [];
    poollocation{i}   = mypoollocation( zeros( AE{i-1}.conv_dim  - AE{i}.kernelsize +1, AE{i-1}.conv_dim - AE{i}.kernelsize +1, AE{i}.outputsize   ),  AE{i}.poolsize);
%     AE{i}.max_index = gpuArray.zeros(AE{i}.pool_dim, AE{i}.pool_dim, AE{i}.outputsize, 1,  'int32');
end
%    AE{end}.final_fea = zeros(AE{end}.pool_dim * AE{end}.pool_dim * AE{end}.outputsize, num_images, 'single');   
    AE{end}.final_fea = [];
tic;
for j=1: num_images

    if mod(j,1000)==0
        fprintf('%d \n',j); toc;
    end
    AE{1}.a = gpuArray(img(:,:,:,j));
    final_fea = [];
    for i=2:numel(AE)
         coldata = gpu_im2col(AE{i-1}.a, AE{i}.kernelsize, 1, AE{i}.kcol); % eg: (84*84)*507
         % ------------------normalization -------------------------------
         if AE{i}.NORMF == 1 && i<= numel(AE)
%              coldata = bsxfun(@minus, coldata, AE{i}.mean_patch');
% %              coldata = max(min(coldata, AE{i}.pstd), -AE{i}.pstd) / AE{i}.pstd;
% %              coldata = (coldata + 1) * 0.45 + 0.05;
         end
         % ---------------------------------------------------------------
         temp_conv = coldata *  AE{i}.W ;   
         temp_conv = bsxfun(@plus, temp_conv, AE{i}.b'); 
         if i<= numel(AE)
             temp_conv = activefunc(temp_conv, AE{i}.type);
         end
         conv_feature = reshape(temp_conv, AE{i}.conv_dim, AE{i}.conv_dim, AE{i}.outputsize);
         conv_feature = gather(conv_feature);
         
         switch AE{i}.pooltype
             case 'max'
                 [AE{i}.a, ~]= MaxPooling(conv_feature, single([AE{i}.poolsize AE{i}.poolsize])); 
             case 'mean'
                 AE{i}.a = mean(  conv_feature(poollocation{i})  );
             case 'kmax'
                 sortx = sort( conv_feature( poollocation{i} ),1, 'descend');
                 AE{i}.a = mean(sortx(1:AE{i}.K,:,:));
             case 'weighted_kmax'
                 sortx = sort( conv_feature( poollocation{i} ),1, 'descend');
                 AE{i}.a = sum(sortx(1:AE{i}.K,:,:).^2) ./ (sum(sortx(1:AE{i}.K,:,:))+0.0001); % attention!
              case 'P_norm'
                 p=2;
                 x_temp = conv_feature( poollocation{i} );
                 AE{i}.a = (  mean( x_temp .^p  ) ) .^(1/p);    
              case 'stochastic'
                 x_temp = conv_feature( poollocation{i} );
                 AE{i}.a = sum(x_temp.^2) ./  ( sum(x_temp)+0.0001) ;
             case 'smooth_max'
                 x_temp = conv_feature( poollocation{i} );
                 alpha  = mean(x_temp);
%                  P = AE{i}.poolsize ^2;
                 P=20;
                 AE{i}.a = 1-(1-alpha) .^P;
              case 'max_spm'
                 [AE{i}.a, ~]= MaxPooling(conv_feature, single([AE{i}.poolsize AE{i}.poolsize])); 
                 AE{i}.spma = max( reshape(conv_feature, AE{i}.conv_dim ^2, AE{i}.outputsize) );
                          
              case 'mean_spm'
                 AE{i}.a = mean(  conv_feature(poollocation{i})  ); 
                 AE{i}.spma = mean( reshape(conv_feature, AE{i}.conv_dim ^2, AE{i}.outputsize) );

              case 'kmax_spm'
                 K1 = AE{i}.K;
                 sortx = sort( conv_feature( poollocation{i} ),1, 'descend');
                 AE{i}.a = mean(sortx(1:K1,:,:));  
                 K2 = K1;
%                   K2 = 500;
                 sorty = sort( reshape(conv_feature, AE{i}.conv_dim ^2, AE{i}.outputsize) , 1 ,  'descend');
                 AE{i}.spma = mean(sorty(1:K2,:));
   
              case 'weighted_kmax_spm'
                 K1 = AE{i}.K;
                 sortx = sort( conv_feature( poollocation{i} ),1, 'descend');
                 AE{i}.a = sum(sortx(1:K1,:,:).^2) ./ (sum(sortx(1:K1,:,:))+0.0001); % attention!
                 
                 K2 = K1;
                 sorty = sort( reshape(conv_feature, AE{i}.conv_dim ^2, AE{i}.outputsize) , 1 ,  'descend');
                 AE{i}.spma = sum(sorty(1:K2,:,:).^2) ./ (sum(sorty(1:K2,:,:))+0.0001);
              case 'Pnorm_spm'
                 p=2;
                 x_temp = conv_feature( poollocation{i} );
                 AE{i}.a = (  mean( x_temp .^p  ) ) .^(1/p); 
                 y_temp  = reshape(conv_feature, AE{i}.conv_dim ^2, AE{i}.outputsize);
                 AE{i}.spma = (  mean( y_temp .^p  ) ) .^(1/p); 
                  
              case 'stochastic_spm'
                 x_temp = conv_feature( poollocation{i} );
                 AE{i}.a = sum(x_temp.^2) ./  (sum(x_temp)+0.0001) ;
                 y_temp  = reshape(conv_feature, AE{i}.conv_dim ^2, AE{i}.outputsize);
                 AE{i}.spma = sum(y_temp.^2) ./  (sum(y_temp)+0.0001) ; 
                 
             case 'sm_spm'
%                  P = AE{i}.poolsize ^2;
                 P=64;
                 x_temp = conv_feature( poollocation{i} );
                 alpha  = mean(x_temp);                
                 AE{i}.a = 1-(1-alpha) .^P;
                 
                 y_temp = reshape(conv_feature, AE{i}.conv_dim ^2, AE{i}.outputsize);
                 alphay = mean(y_temp);
                 AE{i}.spma = 1-(1-alphay) .^P;  
                 
                                    
         end

    end
    
    w = 1/ AE{i}.pool_dim^2;
    w = 1;
    final_fea = [ w*AE{end}.a(:); AE{end}.spma(:)] ;
    AE{end}.final_fea(:,j) = final_fea(:);
    

end        

end



        
    


