






% test gpu conv
% input configuration
%-----------------------------------------------------------------------
% img = randn(225,225,3,9000,'single');
% filter = randn(10,10,3,1000,'single');
% bias = randn(1000,1,'single');
% pool_size = 54;

% layer ����Ҫȡpatch���ǲ��ָ�롣�Ƕ�ǰһ�������ͼȡpatch
function    [patches, AE] = gpu_conv_patch(img, AE, layer )

[AE{1}.conv_dim, ~, AE{1}.outputsize , num_images] = size(img);
AE{1}.pool_dim = AE{1}.conv_dim;
  
for i=2:numel(AE)
    AE{i}.conv_dim = ( AE{i-1}.pool_dim - AE{i}.kernelsize + 1 ) ;
%     AE{i}.outputsize = size(AE{i}.W, 2);
    AE{i}.kcol =  parallel.gpu.CUDAKernel('im2col.ptx','im2col.cu'); 
    AE{i}.conv_nth = AE{i}.outputsize * AE{i}.conv_dim^2;
    AE{i}.kcol.ThreadBlockSize = [1024];
    AE{i}.kcol.GridSize = [floor((AE{i}.conv_nth + 1024 - 1) / 1024)];
    AE{i}.pool_dim = floor( AE{i}.conv_dim / AE{i}.poolsize );
    AE{i}.pool_nth = AE{i}.outputsize * AE{i}.pool_dim^2;
    AE{i}.kmax = parallel.gpu.CUDAKernel('MaxPool.ptx','MaxPool.cu'); 
    AE{i}.kmax.ThreadBlockSize = [1024];
    AE{i}.kmax.GridSize = [floor((AE{i}.pool_nth + 1024 - 1) / 1024)];
    AE{i}.kmean = parallel.gpu.CUDAKernel('meanpool.ptx','meanpool.cu'); 
    AE{i}.kmean.ThreadBlockSize = [1024];
    AE{i}.kmean.GridSize = [floor((AE{i}.pool_nth + 1024 - 1) / 1024)];
    AE{i}.a = gpuArray.zeros(AE{i}.pool_dim, AE{i}.pool_dim, AE{i}.outputsize, 'single');
%     AE{i}.max_index = gpuArray.zeros(AE{i}.pool_dim, AE{i}.pool_dim, AE{i}.outputsize, 1,  'int32');
end
%   AE{end}.final_fea = zeros(AE{end}.pool_dim * AE{end}.pool_dim * AE{end}.outputsize, num_images, 'single');   
  

 patches = zeros(AE{layer}.inputsize, AE{layer}.numpatches ,'single');
 
for j=1: num_images

    if mod(j,10000) == 0
        fprintf('%d \n',j); 
    end
    AE{1}.a = gpuArray(img(:,:,:,j));
    for i=2:layer-1
         coldata = gpu_im2col(single(AE{i-1}.a), AE{i}.kernelsize, 1, AE{i}.kcol);
         % ------------------normalization -------------------------------
         if AE{i}.NORMF == 1
             coldata = bsxfun(@minus, coldata, AE{i}.mean_patch');
%              coldata = max(min(coldata, AE{i}.pstd), -AE{i}.pstd) / AE{i}.pstd;
%              coldata = (coldata + 1) * 0.45 + 0.05;
         end
         % ---------------------------------------------------------------
         temp_conv = coldata *  AE{i}.W ;   
         temp_conv = bsxfun(@plus, temp_conv, AE{i}.b'); 
         temp_conv = activefunc(temp_conv, AE{i}.type);
         conv_feature = reshape(temp_conv, AE{i}.conv_dim, AE{i}.conv_dim, AE{i}.outputsize);
        
         switch AE{i}.pooltype
             case 'max'
                 max_index = gpuArray.zeros(AE{i}.pool_dim, AE{i}.pool_dim, AE{i}.outputsize, 1,  'int32');
                 [AE{i}.a, max_index] = feval(AE{i}.kmax, AE{i}.pool_nth, conv_feature,  AE{i}.outputsize, AE{i}.conv_dim, AE{i}.conv_dim, ...
                                            AE{i}.pool_dim, AE{i}.pool_dim, AE{i}.poolsize, AE{i}.poolsize, AE{i}.a, max_index);  
             case 'mean'
                 AE{i}.a = feval(AE{i}.kmean, AE{i}.pool_nth, conv_feature,  AE{i}.outputsize, AE{i}.conv_dim, AE{i}.conv_dim, ...
                                        AE{i}.pool_dim, AE{i}.pool_dim, AE{i}.poolsize, AE{i}.poolsize, AE{i}.a); 
         end
%          AE{i}.a = sigmoid(AE{i}.a);
    end

%     batch_fea(:,:,:, mod(j-1, batchsize) +1) =  gather(AE{layer-1}.a);
%     if mod(j, batchsize) == 0
%          t = j / batchsize;
%          t_patch = ceil( AE{layer}.numpatches * batchsize/ num_images );
%          patches(:, t_patch * (t-1) +1 : t_patch * t) = samplepatches(batch_fea, AE{layer}.kernelsize, t_patch);
%     end   
      t = ceil( AE{layer}.numpatches / num_images );
      t_patch = samplepatches( gather(AE{layer-1}.a), AE{layer}.kernelsize, t );
      patches(:, (j-1) * t + 1 : j*t) = t_patch;
      

end
size(patches)
 kk=randperm(size(patches, 2));
 patches = patches(:, kk(1:AE{layer}.numpatches));
        
end



        
    


