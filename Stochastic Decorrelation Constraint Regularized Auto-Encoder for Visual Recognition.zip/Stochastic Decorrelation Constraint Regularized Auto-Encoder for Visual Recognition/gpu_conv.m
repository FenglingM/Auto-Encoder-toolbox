



% test gpu conv
% input configuration
%-----------------------------------------------------------------------
% img = randn(225,225,3,9000,'single');
% filter = randn(10,10,3,1000,'single');
% bias = randn(1000,1,'single');
% pool_size = 54;


function out_img = gpu_conv(img, filter, bias, pool_size)
filter = gpuArray(single(filter));
bias = gpuArray(single(bias));
kconv = parallel.gpu.CUDAKernel('conv.ptx','conv.cu'); 
kmax = parallel.gpu.CUDAKernel('MaxPool.ptx','MaxPool.cu'); 
kcol =  parallel.gpu.CUDAKernel('im2col.ptx','im2col.cu'); 
conv_bin = {'im2col', 'conv'};

% ----------------------------------------------------------------------


[data_height, data_width, data_channels, num_images] = size(img);
[filter_size, ~, filter_channels, fea_channels] = size(filter);

conv_height = data_height - filter_size +1;
conv_width = data_width - filter_size +1;

minibatch = 1;
conv_feature = gpuArray.zeros(conv_height, conv_width, fea_channels, minibatch,  'single');


pooled_height = conv_height / pool_size ;
pooled_width =  conv_width / pool_size;
pool_feature = gpuArray.zeros(pooled_height, pooled_width, fea_channels, minibatch, 'single');
max_index = gpuArray.zeros(pooled_height, pooled_width, fea_channels,minibatch,  'int32');
batchsize = 1;
batch_poolfea = gpuArray.zeros(pooled_height, pooled_width, fea_channels, batchsize,  'single'); % ��pooledfeatures �Ž�����ط����棬Ȼ��ͳһ���Դ���ȡ���ڴ档

out_img = zeros(pooled_height, pooled_width, fea_channels, num_images, 'single');

%% 
%------------------------------------------------------------------------

        num_kernels = data_channels * conv_height * conv_width;
        pool_nth = pooled_height* pooled_width* fea_channels;
        kcol.ThreadBlockSize = [1024];
        kcol.GridSize = [floor((num_kernels + 1024 - 1) / 1024)];
        kmax.ThreadBlockSize = [1024];
        kmax.GridSize = [floor((pool_nth + 1024 - 1) / 1024)];
        W = reshape(filter, filter_size^2 * filter_channels,  fea_channels);
        
        for i=1: num_images/minibatch
            
            if mod(i,1000)==0
                fprintf('%d \n',i); 
            end
            
            miniimg = gpuArray( img(:,:,:, (i-1)* minibatch +1 : i * minibatch ) );
            coldata = gpu_im2col(miniimg, filter_size, 1, kcol);
            temp_conv = coldata *  W ;   
            temp_conv = bsxfun(@plus, temp_conv, bias');   
            conv_feature = reshape(temp_conv, conv_height, conv_width, fea_channels);
            [pool_feature, max_index] = feval(kmax, pool_nth, conv_feature, fea_channels, conv_height, conv_width, pooled_height, pooled_width, pool_size, pool_size, pool_feature, max_index);
            
            j = mod(i-1, batchsize/minibatch ) +1;
            batch_poolfea(:,:,:,(j-1)*minibatch +1: j*minibatch ) = pool_feature;
            if mod(i, batchsize/minibatch)==0
                t = i*minibatch /batchsize;
                out_img(:,:,:, batchsize* (t-1) +1 : batchsize* t) = gather(batch_poolfea);
%                 toc;
            end
            
        end
        
        out_img = sigmoid(out_img);
        
        
        


end



        
    


